const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /api/trainees
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM trainee');
    console.log(`✅ Successfully fetched ${rows.length} records from MySQL.`);
    res.json(rows);
  } catch (err) {
    console.error('⚠️ Database Query Error:', err.message);

    const mockTrainees = [
      { id: 1, name: "Aarav Sharma", course: "Web Development", status: "Employed", wage: 25000 },
      { id: 2, name: "Priya Patel", course: "Data Entry", status: "In Training", wage: 0 },
      { id: 3, name: "Rahul Verma", course: "Solar Technician", status: "Employed", wage: 22000 }
    ];

    res.json(mockTrainees);
  }
});

// MUST BE AT THE VERY BOTTOM
module.exports = router;