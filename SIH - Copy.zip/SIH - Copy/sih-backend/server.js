const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

// 1. Trainees Route
const traineesRouter = require('./routes/trainees');
if (typeof traineesRouter === 'function' || (traineesRouter && traineesRouter.name === 'router')) {
  app.use('/api/trainees', traineesRouter);
}

// 2. Dashboard Stats Route (Fixes the 404!)
app.get('/api/dashboard/stats', (req, res) => {
  res.json({
    totalTrainees: 1250,
    placedTrainees: 980,
    activeCourses: 14,
    avgWageIncrease: "24%"
  });
});

app.get('/', (req, res) => {
  res.send('SIH Backend API is running...');
});

// 3. Server Listener (MUST BE AT THE VERY BOTTOM)
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});